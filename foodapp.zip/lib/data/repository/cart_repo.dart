import 'dart:convert';

import 'package:foodapp/utils/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../models/cart_model.dart';

class CartRepo{

  final SharedPreferences sharedPreferences;
  CartRepo({required this.sharedPreferences});

  List<String> cart =[];

  void addToCartList(List<CartModel>cartList){
      cart=[];
      /*
      convert obejct to String because shared preferences only accept string
      * */
      cartList.forEach((element) {
         return cart.add(jsonEncode(element));
      });

      //short form of above cart list add function
      //cartList.forEach((element)=> cart.add(jsonEncode(element)));

      sharedPreferences.setStringList(AppConstants.CART_LIST, cart);
      //print(sharedPreferences.getStringList(AppConstants.CART_LIST));
      getCartList();
  }

  List<CartModel> getCartList(){
    List<String> carts =[];
    if(sharedPreferences.containsKey(AppConstants.CART_LIST)){
       carts = sharedPreferences.getStringList(AppConstants.CART_LIST)!;
       print("inside get cartList" + carts.toString());
    }
    List<CartModel> cartList=[];

    carts.forEach((element) {
      cartList.add(CartModel.fromJson(jsonDecode(element)));
    });

    //short form of above cart list add function
    //carts.forEach((element)=>cartList.add(CartModel.fromJson(jsonDecode(element))));

    return cartList;
  }

}